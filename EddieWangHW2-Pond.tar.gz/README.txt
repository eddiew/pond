To build:
    edit src/ofApp.cpp:14 to use the correct audio input device (remove to use default device)
    edit config.make to point to your openframeworks installation
    run `make`
    
To use:
    Run `./bin/hw2`
    Press <space> to toggle detail display
    Press <e> to pause the audio stream
    Press <s> to resume the audio stream
    Make noise!

Description:
    This audio visualizer is intended to mimic the surface of a pond. Sounds create ripples on the surface like drops of water. The y-position of each drop corresponds roughly to the octave of the sound that created it, and the x-position is totally random, as if controlled by nature. Deep (low frequency) sounds create red ripples that oscillate slowly. Bright (high frequency) sounds create blue ripples that oscillate quickly.
